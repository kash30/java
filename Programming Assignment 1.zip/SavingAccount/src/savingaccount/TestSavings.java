/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savingaccount;

/**
 *
 * @author Kashish Gujral
 */
/* TestSavings */
public class TestSavings
{
    public static void main(String[] args) 
    {
        SavingAccount saver1 = new SavingAccount(2000.0);
        SavingAccount saver2 = new SavingAccount(3000.0);
        
        SavingAccount.setInterestRate(0.04); //set to 4%
        
        
        
        System.out.printf("Saving Account Balances \n");
        
        System.out.format("%-8s %9s %9s\n" , "Month" , "Saver1" , "Saver2");
        
        for(int i=0; i < 13; i++)
        {
            saver1.calculateMonthlyInterest();
            saver2.calculateMonthlyInterest();
            
            System.out.format("%-8d %9.2f %9.2f\n" , i + 1,
                    saver1.getSavingsBalance(),
                    saver2.getSavingsBalance() );
                    
            if(i == 11)
            { // change rate after 12th 
                SavingAccount.setInterestRate(0.05);
                
            }
        }    
    
        
    }
    
}
